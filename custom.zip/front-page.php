<?php get_header(); ?>

This is my front-page

<div class="col-md-12 col-sm-12 col-xs-12 container">
    <div class="col-md-6 col-sm-6 col-xs-6">
        This is content 
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6">
        This is sidebar
    </div>



</div>

<?php get_footer(); ?>