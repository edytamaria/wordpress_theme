<?php
http_response_code(404);
include('my_404.php');
die();