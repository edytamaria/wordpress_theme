$(document).ready(function() {

    alert('You loaded your js file');
});